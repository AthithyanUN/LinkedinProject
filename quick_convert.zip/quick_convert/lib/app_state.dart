import 'package:flutter/material.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _CurrencAmount = '';
  String get CurrencAmount => _CurrencAmount;
  set CurrencAmount(String _value) {
    _CurrencAmount = _value;
  }

  double _S1 = 0.0;
  double get S1 => _S1;
  set S1(double _value) {
    _S1 = _value;
  }

  double _S2 = 0.0;
  double get S2 => _S2;
  set S2(double _value) {
    _S2 = _value;
  }

  String _convlist = '';
  String get convlist => _convlist;
  set convlist(String _value) {
    _convlist = _value;
  }

  bool _currencySet = false;
  bool get currencySet => _currencySet;
  set currencySet(bool _value) {
    _currencySet = _value;
  }

  String _NumberList = '';
  String get NumberList => _NumberList;
  set NumberList(String _value) {
    _NumberList = _value;
  }

  double _Numbertotal = 0.0;
  double get Numbertotal => _Numbertotal;
  set Numbertotal(double _value) {
    _Numbertotal = _value;
  }

  String _CurrencyType1 = 'USD';
  String get CurrencyType1 => _CurrencyType1;
  set CurrencyType1(String _value) {
    _CurrencyType1 = _value;
  }

  String _CurrencyType2 = 'INR';
  String get CurrencyType2 => _CurrencyType2;
  set CurrencyType2(String _value) {
    _CurrencyType2 = _value;
  }

  DateTime? _updatetime;
  DateTime? get updatetime => _updatetime;
  set updatetime(DateTime? _value) {
    _updatetime = _value;
  }

  bool _freespace = false;
  bool get freespace => _freespace;
  set freespace(bool _value) {
    _freespace = _value;
  }

  List<String> _listcountry = [];
  List<String> get listcountry => _listcountry;
  set listcountry(List<String> _value) {
    _listcountry = _value;
  }

  void addToListcountry(String _value) {
    _listcountry.add(_value);
  }

  void removeFromListcountry(String _value) {
    _listcountry.remove(_value);
  }

  void removeAtIndexFromListcountry(int _index) {
    _listcountry.removeAt(_index);
  }

  void updateListcountryAtIndex(
    int _index,
    String Function(String) updateFn,
  ) {
    _listcountry[_index] = updateFn(_listcountry[_index]);
  }

  void insertAtIndexInListcountry(int _index, String _value) {
    _listcountry.insert(_index, _value);
  }

  List<String> _currencyList = [];
  List<String> get currencyList => _currencyList;
  set currencyList(List<String> _value) {
    _currencyList = _value;
  }

  void addToCurrencyList(String _value) {
    _currencyList.add(_value);
  }

  void removeFromCurrencyList(String _value) {
    _currencyList.remove(_value);
  }

  void removeAtIndexFromCurrencyList(int _index) {
    _currencyList.removeAt(_index);
  }

  void updateCurrencyListAtIndex(
    int _index,
    String Function(String) updateFn,
  ) {
    _currencyList[_index] = updateFn(_currencyList[_index]);
  }

  void insertAtIndexInCurrencyList(int _index, String _value) {
    _currencyList.insert(_index, _value);
  }

  String _alert = '';
  String get alert => _alert;
  set alert(String _value) {
    _alert = _value;
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
