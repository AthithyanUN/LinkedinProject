import 'dart:convert';
import 'dart:typed_data';

import '../../flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class ExhnagerateFIRSTCall {
  static Future<ApiCallResponse> call({
    String? s1 = '',
    String? s2 = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'exhnagerateFIRST',
      apiUrl:
          'https://v6.exchangerate-api.com/v6/3a362c7b5471452f2dcce31b/pair/${s1}/${s2}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }

  static dynamic rate(dynamic response) => getJsonField(
        response,
        r'''$.conversion_rate''',
      );
  static dynamic updatetime(dynamic response) => getJsonField(
        response,
        r'''$.time_next_update_utc''',
      );
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
